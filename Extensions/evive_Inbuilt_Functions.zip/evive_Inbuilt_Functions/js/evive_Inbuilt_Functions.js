
(function(ext) {
    var device = null;
    var joystick = [[1,0,0],[2,0,0],[3,0,0],[4,0,0],[5,0,0]]
    
	var levels = {
        HIGH:1,
        LOW:0
    };
    var states ={
        Up: 1,
        Down: 3,
    };
    var direction = {
        Up: 1,
        Down: 3,
        Left: 4,
        Right: 2,
    }
    
	ext.resetAll = function(){};
    ext.runArduino = function(){};

    ext.tactile = function(nextID,pin){
        getPackage(nextID,30,pin+37);
    };

    ext.slide = function(nextID,pin,state){
        state = typeof state=="string"?states[state]:new Number(state);
        if(pin==1)
        {
            if (state==1) pin=40;
            else if (state==3) pin=41;
        }
        else if(pin==2)
        {
            if (state==1) pin=42;
            else if (state==3) pin=43;
        }
        getPackage(nextID,30,pin);
    };

    ext.run_motor = function(pin,dir,vel){
        if (pin==1)
            {runPackage(10,pin,dir,vel);}
        else if (pin==2)
            {runPackage(9,pin,dir,vel);}
    };

    ext.lock_motor = function(pin){
        if (pin==1)
            {runPackage(10,pin,3,0);}
        else if (pin==2)
            {runPackage(9,pin,3,0);}
    };

    ext.free_motor = function(pin){
        if (pin==1)
            {runPackage(10,pin,4,0);}
        else if (pin==2)
            {runPackage(9,pin,4,0);}
    };

    ext.potentiometer = function(nextID,pin){
        getPackage(nextID,31,pin+8);
    };

    ext.navKeyZ = function(nextID){
        getPackage(nextID,30,19);
    };

    ext.set_time = function(hr,min,sec){
        runPackage(46,hr,min,sec);
    };

    ext.set_date = function(date,month,year,weekday){
        runPackage(47,date,month,year,weekday);
    };

    ext.get_time = function(nextID,pin){
        getPackage(nextID,46,pin);
    };

    ext.get_date = function(nextID,pin){
        getPackage(nextID,47,pin);
    };

    ext.touch = function(nextID,pin){
        getPackage(nextID,44,pin);
    };

    ext.navkey = function(nextID,pin){
        getPackage(nextID,45,typeof pin=="string"?direction[pin]:new Number(pin));
    };

    function sendPackage(argList, type){
        var bytes = [0xff, 0x55, 0, 0, type];
        for(var i=0;i<argList.length;++i){
            var val = argList[i];
            if(val.constructor == "[class Array]"){
                bytes = bytes.concat(val);
            }else{
                bytes.push(val);
            }
        }
        bytes[2] = bytes.length - 3;
        device.send(bytes);
    }

    function runPackage(){
        sendPackage(arguments, 2);
    }

    function getPackage(){
        var nextID = arguments[0];
        Array.prototype.shift.call(arguments);
        sendPackage(arguments, 1);
    }


    var inputArray = [];
    var _isParseStart = false;
    var _isParseStartIndex = 0;
    function processData(bytes) {
        var len = bytes.length;
        if(_rxBuf.length>30){
            _rxBuf = [];
        }
        for(var index=0;index<bytes.length;index++){
            var c = bytes[index];
            _rxBuf.push(c);
            if(_rxBuf.length>=2){
                if(_rxBuf[_rxBuf.length-1]==0x55 && _rxBuf[_rxBuf.length-2]==0xff){
                    _isParseStart = true;
                    _isParseStartIndex = _rxBuf.length-2;
                }
                if(_rxBuf[_rxBuf.length-1]==0xa && _rxBuf[_rxBuf.length-2]==0xd&&_isParseStart){
                    _isParseStart = false;
                    
                    var position = _isParseStartIndex+2;
                    var extId = _rxBuf[position];
                    position++;
                    var type = _rxBuf[position];
                    position++;
                    //1 byte 2 float 3 short 4 len+string 5 double
                    var value;
                    switch(type){
                        case 1:{
                            value = _rxBuf[position];
                            position++;
                        }
                            break;
                        case 2:{
                            value = readFloat(_rxBuf,position);
                            position+=4;
                            if(value<-255||value>1023){
                                value = 0;
                            }
                        }
                            break;
                        case 3:{
                            value = readInt(_rxBuf,position,2);
                            position+=2;
                        }
                            break;
                        case 4:{
                            var l = _rxBuf[position];
                            position++;
                            value = readString(_rxBuf,position,l);
                        }
                            break;
                        case 5:{
                            value = readDouble(_rxBuf,position);
                            position+=4;
                        }
                            break;
                        case 6:
                            value = readInt(_rxBuf,position,4);
                            position+=4;
                            break;
                    }
                    if(type<=6){
                        responseValue(extId,value);
                    }else{
                        responseValue();
                    }
                    _rxBuf = [];
                }
            } 
        }
    }
    function readFloat(arr,position){
        var f= [arr[position],arr[position+1],arr[position+2],arr[position+3]];
        return parseFloat(f);
    }
    function readInt(arr,position,count){
        var result = 0;
        for(var i=0; i<count; ++i){
            result |= arr[position+i] << (i << 3);
        }
        return result;
    }
    function readDouble(arr,position){
        return readFloat(arr,position);
    }
    function readString(arr,position,len){
        var value = "";
        for(var ii=0;ii<len;ii++){
            value += String.fromCharCode(_rxBuf[ii+position]);
        }
        return value;
    }
    function appendBuffer( buffer1, buffer2 ) {
        return buffer1.concat( buffer2 );
    }







    // Extension API interactions
    var potentialDevices = [];
    ext._deviceConnected = function(dev) {
        potentialDevices.push(dev);

        if (!device) {
            tryNextDevice();
        }
    }

    function tryNextDevice() {
        // If potentialDevices is empty, device will be undefined.
        // That will get us back here next time a device is connected.
        device = potentialDevices.shift();
        if (device) {
            device.open({ stopBits: 0, bitRate: 115200, ctsFlowControl: 0 }, deviceOpened);
        }
    }

    function deviceOpened(dev) {
        if (!dev) {
            // Opening the port failed.
            tryNextDevice();
            return;
        }
        device.set_receive_handler('tinkering',function(data) {
            processData(data);
        });
    };

    ext._deviceRemoved = function(dev) {
        if(device != dev) return;
        device = null;
    };

    ext._shutdown = function() {
        if(device) device.close();
        device = null;
    };

    ext._getStatus = function() {
        if(!device) return {status: 1, msg: 'motor disconnected'};
        return {status: 2, msg: 'motor connected'};
    }

    var descriptor = {};
	ScratchExtensions.register('motor', descriptor, ext, {type: 'serial'});
})({});
