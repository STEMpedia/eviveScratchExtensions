evive
This firmware is developed for evive [http://evive.cc]. It enables the menu based visual interface for Arduino programs.

eviveFirmware 1.0.3 20170729
-Increased the speed of TFT display using TFT _ST7735 library and graphics library. Earlier versions used Adafruit GFX and ST7735 library.
-Added TFTSerial Library to enable the user to print any data on TFT screen anywhere in the firmware or user defined functions.
-Changed variable "lcd" to "tft" and related functions.