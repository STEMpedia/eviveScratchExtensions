/*	
	Gamepad.h - library for displaying input from the gamepad (android app).
	Created by - Ajay Rahul , 28/05/17
	*Almost feels like using a PS*
	WARNING: this library will work only with the default values/letters of the button 	
	If the button press command is changed in the android app , then it won't work
	This library has one function : getInput(): returns a string - a letter or analog values(in form of an angle from 0-360)
	it is used to get the input from the app , and accordingly used in the arduino code.
*/
 #include "Arduino.h"
 #include "Gamepad.h"


Gamepad::Gamepad( )
{	
  	string = "";
  	str=-1;
}

int Gamepad::getInput(){

  	if (Serial3.available() > 0){	
    		string = "";
    		str=-1;   		
			
	}

    
    while(Serial3.available() > 0)
    {
      command = ((char)Serial3.read());
      
      if(command == '~')
      {
        break;
      }
      
      else
      {
        string += command;
      }
      
      delay(1);
    }

	 if (Serial3.available()< 0) {
			string ="-1";
			Serial3.flush();
			

	}

	if(string!="" && string !="-1"){  		//switch case to identify the letter.
		//Serial.println("hey");
		switch(string[0]){
			case 'w':
				//btn_pressed="UP ARROW";
				str = 1;
				break;
			case 's':
				//btn_pressed="DOWN ARROW";
				str = 2;
				break;
			case 'a':
				//btn_pressed="LEFT ARROW";
				str = 3;
				break;
			case 'd':
				//btn_pressed="RIGHT ARROW";
				str = 4;
				break;
			case '8':
				//btn_pressed="TRIANGLE BUTTON";
				str = 5;
				break;
			case '2':
				//btn_pressed="CROSS BUTTON";
				str = 6;
				break;
			case '4':
				//btn_pressed="SQUARE BUTTON";
				str = 7;
				break;
			case '6':
				//btn_pressed="CIRCLE BUTTON";
				str = 8;
				break;
			case '0':
				//btn_pressed="SELECT BUTTON";
				str = 9;
				break;
			case '1':
				//btn_pressed="START BUTTON";
				str = 10;
				break;
			case 'x':
				//btn_pressed="STOP";
				str=11;
				break;
			//case '@':
			//	str = string.substring(1,4);
				//btn_pressed = str;
			//	break;
			case '`':
				str=-1;
			default :
				//btn_pressed="Invalid";
	            str = -1;
				break;


		}
		
	return str;
		
	}else if(string == ""){
		string="";
		return str;
		
	}

  
}