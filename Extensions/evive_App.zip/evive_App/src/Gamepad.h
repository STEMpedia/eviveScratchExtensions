/*	
	Gamepad.h - library for displaying input from the gamepad (android app).
	Created by - Ajay Rahul , 28/05/17
	*Almost feels like using a PS*
	WARNING: this library will work only with the default values/letters of the button 	
	If the button press command is changed in the android app , then it won't work

*/

#ifndef Gamepad_h
#define Gamepad_h

#include "Arduino.h"


class Gamepad
{
  public:
  	Gamepad();
  	int getInput();
  
  private:
   	char command;
   	String string;
   	int str;
};

#endif
