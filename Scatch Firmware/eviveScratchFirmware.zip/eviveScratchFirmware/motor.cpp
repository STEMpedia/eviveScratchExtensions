/*library tested 30 NOVEMBER
  Made by Deep Goel and Kartik Gupta
*/

#include "motor.h"
//#include <botconfig.h>
#include <Arduino.h>
Motor::Motor()									//constructor
{	
	attachMotor(-1,-1,-1);
}

Motor::Motor(int Dir1, int Dir2, int Pwm )		// parametrised constructor
{	
	attachMotor(Dir1,Dir2,Pwm);
}

void Motor::attachMotor(int Dir1,int Dir2,int Pwm)
{
	pwm_pin= Pwm;
	dir1_pin		= Dir1;
	dir2_pin		= Dir2;
	if(dir1!=-1 && dir2!=-1 && pwm_pin!=-1)
	{	
		pinMode(pwm_pin,OUTPUT);
		pinMode(dir1_pin,OUTPUT);
		pinMode(dir2_pin,OUTPUT);
	}
	pwm			= 0;
	speed		= 0;
	mean_speed	= 255;
	//lockMotor();	//Lock the Motor initially
	damping=10;
	}


void Motor::moveMotor(int dir, int Pwm)			//+ve for CW and -ve for CCW.
{
	
	if(dir==1)
	{	
		digitalWrite(dir1_pin,HIGH);
		digitalWrite(dir2_pin,LOW);
	}
	if(dir==2)
	{	
		digitalWrite(dir1_pin,LOW);
		digitalWrite(dir2_pin,HIGH);
	}
	changePWM(Pwm);
//	Serial.println("PWM=");
//	Serial.print(Pwm);
}

/*
void Motor::moveMotor(int Dir1,int Dir2,int Pwm)
{
	if(Dir1==1 && Dir2==0)
		moveMotor(Pwm);
	if(Dir1==0 && Dir2==1)
		moveMotor(-Pwm);
}
*/
void Motor::stopMotor() 				//By default stop motor will lock motor
{	
	lockMotor();
}

void Motor::lockMotor()
{
	digitalWrite(dir1_pin,HIGH);			//case of motor lock
	digitalWrite(dir2_pin,HIGH);
	analogWrite(pwm_pin,255);
	pwm=0;	
}

void Motor::freeMotor()
{
	digitalWrite(dir1_pin,LOW);			//case of motor free
	digitalWrite(dir2_pin,LOW);
	analogWrite(pwm_pin,0);
	pwm=0;
}
		

void Motor::changePWM(int Pwm)					//Just to change the PWM
{
	pwm = Pwm>255 ? 255 : (Pwm < -255 ? -255 :Pwm);
	analogWrite(pwm_pin,abs(pwm));
}

